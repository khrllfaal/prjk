-- Tabel Absensi, Tarif, Rekap Gaji & Kasbon (Tenaga Kerja). Aman dijalankan berulang (IF NOT EXISTS).
-- Butuh tabel users & projects yang sudah ada. Jalankan lewat phpMyAdmin > SQL / Import.
SET NAMES utf8mb4;
-- ============================================================
-- Absensi & Rekap Gaji pekerja proyek
-- ============================================================

-- Tarif per proyek per status (Kepala Tukang, Tukang, Laden, ...). Nilai ini
-- disalin (snapshot) ke setiap baris absen saat disimpan, jadi kenaikan tarif
-- tidak mengubah gaji yang sudah lewat.
CREATE TABLE IF NOT EXISTS labor_rates (
  project_id    VARCHAR(40) NOT NULL,
  tim           VARCHAR(80) NOT NULL DEFAULT '',   -- '' = tarif standar proyek; isi = tarif khusus tim tsb
  grade         VARCHAR(10) NOT NULL,
  tarif_harian  DECIMAL(14,2) NOT NULL DEFAULT 0,
  tarif_lembur  DECIMAL(14,2) NOT NULL DEFAULT 0, -- per jam
  updated_by    VARCHAR(40) NULL,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (project_id, tim, grade),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS workers (
  id            VARCHAR(40) PRIMARY KEY,
  project_id    VARCHAR(40) NOT NULL,
  nama          VARCHAR(120) NOT NULL,
  grade         VARCHAR(10) NOT NULL,           -- KTK, TK, LD, OBK, SPR, OMX, LAIN
  tim           VARCHAR(80) NOT NULL DEFAULT '',
  tarif_harian  DECIMAL(14,2) NULL,             -- tarif khusus orang ini (NULL = ikut tarif status)
  tarif_lembur  DECIMAL(14,2) NULL,
  no_rek        VARCHAR(80) NOT NULL DEFAULT '', -- rekening / e-wallet, opsional
  aktif         TINYINT(1) NOT NULL DEFAULT 1,
  diverifikasi  TINYINT(1) NOT NULL DEFAULT 1,   -- selalu 1 (verifikasi pekerja baru dinonaktifkan)
  diverifikasi_by VARCHAR(40) NULL,
  diverifikasi_at DATETIME NULL,
  borongan      TINYINT(1) NOT NULL DEFAULT 0,   -- 1 = tim borongan: satu penerima, dibayar per tim lewat Tambahan (tarif harian 0)
  induk_id      VARCHAR(40) NULL,                -- pekerja yang sama di proyek lain (setengah hari di dua proyek)
  created_by    VARCHAR(40) NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_workers_project (project_id, aktif),
  INDEX idx_workers_induk (induk_id),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Satu baris = satu pekerja, satu proyek, satu tanggal. hari: 0 / 0.5 / 1.
CREATE TABLE IF NOT EXISTS attendance (
  worker_id     VARCHAR(40) NOT NULL,
  project_id    VARCHAR(40) NOT NULL,
  tgl           DATE NOT NULL,
  hari          DECIMAL(3,1) NOT NULL DEFAULT 0,
  lembur_jam    DECIMAL(4,1) NOT NULL DEFAULT 0,
  grade         VARCHAR(10) NOT NULL DEFAULT '',     -- snapshot
  tim           VARCHAR(80) NOT NULL DEFAULT '',     -- snapshot
  tarif_harian  DECIMAL(14,2) NOT NULL DEFAULT 0,    -- snapshot
  tarif_lembur  DECIMAL(14,2) NOT NULL DEFAULT 0,    -- snapshot
  ket           VARCHAR(255) NOT NULL DEFAULT '',
  rev           INT NOT NULL DEFAULT 0,               -- bertambah tiap diubah: mencegah dua perangkat saling menimpa
  created_by    VARCHAR(40) NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (worker_id, project_id, tgl),
  INDEX idx_att_project_tgl (project_id, tgl),
  INDEX idx_att_tgl (tgl),
  FOREIGN KEY (worker_id) REFERENCES workers(id) ON DELETE CASCADE,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Periode gaji mingguan (Jumat–Kamis) per proyek: draft -> diajukan -> dibayar.
CREATE TABLE IF NOT EXISTS payroll_periods (
  id            VARCHAR(80) PRIMARY KEY,
  project_id    VARCHAR(40) NOT NULL,
  tgl_mulai     DATE NOT NULL,
  tgl_akhir     DATE NOT NULL,
  status        ENUM('draft','diajukan','disetujui','dibayar') NOT NULL DEFAULT 'draft',
  pj_nama       VARCHAR(120) NOT NULL DEFAULT '',  -- penanggung jawab
  grup_nama     VARCHAR(120) NOT NULL DEFAULT '',
  catatan       VARCHAR(255) NOT NULL DEFAULT '',
  diajukan_at   DATETIME NULL, diajukan_by VARCHAR(40) NULL,
  disetujui_at  DATETIME NULL, disetujui_by VARCHAR(40) NULL,   -- diperiksa & disetujui Admin Pusat
  dibayar_at    DATETIME NULL, dibayar_by  VARCHAR(40) NULL,
  UNIQUE KEY uniq_period (project_id, tgl_mulai),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tambahan / potongan pada satu periode. worker_id NULL = untuk seluruh grup
-- (mis. "air galon" +378.000 atau "kasbon" -7.500.000 pada lembar pengajuan).
CREATE TABLE IF NOT EXISTS payroll_adjustments (
  id            VARCHAR(40) PRIMARY KEY,
  period_id     VARCHAR(80) NOT NULL,
  worker_id     VARCHAR(40) NULL,
  tim           VARCHAR(80) NOT NULL DEFAULT '',   -- baris milik satu tim (mis. potong kasbon tim)
  jenis         ENUM('tambah','potong') NOT NULL,
  kategori      VARCHAR(20) NOT NULL DEFAULT 'lainnya', -- kasbon, potongan, bonus, tambahan
  label         VARCHAR(160) NOT NULL,
  qty           DECIMAL(12,3) NULL,
  harga         DECIMAL(14,2) NULL,
  jumlah        DECIMAL(14,2) NOT NULL,
  created_by    VARCHAR(40) NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_adj_period (period_id),
  FOREIGN KEY (period_id) REFERENCES payroll_periods(id) ON DELETE CASCADE,
  FOREIGN KEY (worker_id) REFERENCES workers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Pembayaran gaji. worker_id NULL = baris penyesuaian grup.
CREATE TABLE IF NOT EXISTS payroll_payments (
  id            VARCHAR(40) PRIMARY KEY,
  period_id     VARCHAR(80) NOT NULL,
  worker_id     VARCHAR(40) NULL,
  jumlah        DECIMAL(14,2) NOT NULL,
  tgl_bayar     DATE NOT NULL,
  metode        ENUM('tunai','transfer') NOT NULL DEFAULT 'tunai',
  ket           VARCHAR(255) NOT NULL DEFAULT '',
  created_by    VARCHAR(40) NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  bukti_no      VARCHAR(30) NULL,                 -- nomor Bukti Pembayaran (satu nomor untuk satu kali bayar)
  INDEX idx_pay_period (period_id),
  INDEX idx_pay_bukti (bukti_no),
  FOREIGN KEY (period_id) REFERENCES payroll_periods(id) ON DELETE CASCADE,
  FOREIGN KEY (worker_id) REFERENCES workers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Penghitung nomor dokumen berurut per bulan (BP/2026/10/0001). Naik di dalam transaksi pembayaran: tanpa nomor ganda, tanpa lubang.
CREATE TABLE IF NOT EXISTS doc_counters (
  kode     VARCHAR(8) NOT NULL,
  periode  CHAR(7) NOT NULL,
  terakhir INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (kode, periode)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Borongan: kontrak (satu pekerjaan untuk satu tim), addendum nilai, dan termin pembayaran. Lihat docs/BORONGAN.md.
CREATE TABLE IF NOT EXISTS borongan_kontrak (
  id              VARCHAR(40) PRIMARY KEY,
  no_kontrak      VARCHAR(30) NOT NULL,
  project_id      VARCHAR(40) NOT NULL,
  worker_id       VARCHAR(40) NOT NULL,                  -- tim borongan (workers.borongan = 1)
  nama_pekerjaan  VARCHAR(160) NOT NULL,
  tgl_mulai       DATE NOT NULL,
  nilai           DECIMAL(14,2) NOT NULL,
  retensi_persen  DECIMAL(5,2) NOT NULL DEFAULT 0,
  catatan         VARCHAR(255) NOT NULL DEFAULT '',
  status          ENUM('draft','diajukan','disetujui','selesai','batal') NOT NULL DEFAULT 'draft',
  catatan_kembali VARCHAR(200) NULL,
  created_by      VARCHAR(40) NULL,
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  diajukan_at     DATETIME NULL, diajukan_by VARCHAR(40) NULL,
  disetujui_at    DATETIME NULL, disetujui_by VARCHAR(40) NULL,
  selesai_at      DATETIME NULL, selesai_by VARCHAR(40) NULL,
  batal_at        DATETIME NULL, batal_alasan VARCHAR(200) NULL,
  UNIQUE KEY uq_bk_no (no_kontrak),
  INDEX idx_bk_tim (project_id, worker_id),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (worker_id) REFERENCES workers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS borongan_addendum (
  id          VARCHAR(40) PRIMARY KEY,
  kontrak_id  VARCHAR(40) NOT NULL,
  tgl         DATE NOT NULL,
  jumlah      DECIMAL(14,2) NOT NULL,                    -- positif = tambah nilai, negatif = kurangi
  alasan      VARCHAR(200) NOT NULL DEFAULT '',
  status      ENUM('diajukan','disetujui','ditolak') NOT NULL DEFAULT 'diajukan',
  created_by  VARCHAR(40) NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  diproses_by VARCHAR(40) NULL, diproses_at DATETIME NULL,
  INDEX idx_ba_kontrak (kontrak_id),
  FOREIGN KEY (kontrak_id) REFERENCES borongan_kontrak(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS borongan_termin (
  id                  VARCHAR(40) PRIMARY KEY,
  kontrak_id          VARCHAR(40) NOT NULL,
  no_termin           INT NOT NULL DEFAULT 0,
  jenis               ENUM('termin','lepas_retensi') NOT NULL DEFAULT 'termin',
  tgl                 DATE NOT NULL,
  bruto               DECIMAL(14,2) NOT NULL,
  retensi             DECIMAL(14,2) NOT NULL DEFAULT 0,
  potong_kasbon_aktif TINYINT(1) NOT NULL DEFAULT 1,
  potong_kasbon       DECIMAL(14,2) NOT NULL DEFAULT 0,
  denda               DECIMAL(14,2) NOT NULL DEFAULT 0,
  denda_ket           VARCHAR(160) NOT NULL DEFAULT '',
  bersih              DECIMAL(14,2) NOT NULL DEFAULT 0,
  status              ENUM('diajukan','disetujui','dibayar','ditolak') NOT NULL DEFAULT 'diajukan',
  ket                 VARCHAR(255) NOT NULL DEFAULT '',
  tgl_bayar           DATE NULL,
  metode              ENUM('tunai','transfer') NULL,
  bukti_no            VARCHAR(30) NULL,
  kasbon_id           VARCHAR(40) NULL,
  created_by          VARCHAR(40) NULL,
  created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  disetujui_at        DATETIME NULL, disetujui_by VARCHAR(40) NULL,
  dibayar_at          DATETIME NULL, dibayar_by VARCHAR(40) NULL,
  INDEX idx_bt_kontrak (kontrak_id),
  INDEX idx_bt_bukti (bukti_no),
  FOREIGN KEY (kontrak_id) REFERENCES borongan_kontrak(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Kasbon yang diberikan. Saldo = kasbon diberikan - potongan kasbon pada gaji.
-- worker_id NULL = kasbon atas nama grup/penanggung jawab.
CREATE TABLE IF NOT EXISTS kasbon (
  id            VARCHAR(40) PRIMARY KEY,
  project_id    VARCHAR(40) NOT NULL,
  worker_id     VARCHAR(40) NULL,
  tim           VARCHAR(80) NOT NULL DEFAULT '',   -- kasbon atas nama tim (worker_id kosong)
  tgl           DATE NOT NULL,
  jumlah        DECIMAL(14,2) NOT NULL,
  ket           VARCHAR(255) NOT NULL DEFAULT '',
  created_by    VARCHAR(40) NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ref           VARCHAR(40) NULL,                  -- penghubung ke asal catatan (mis. id termin borongan yang memotong kasbon ini)
  INDEX idx_kasbon_pw (project_id, worker_id),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (worker_id) REFERENCES workers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Pengajuan kasbon dari lapangan: lapangan mengajukan, Akuntan/Admin Pusat memeriksa
-- lalu menyetujui (otomatis tercatat di buku kasbon) atau menolak.
CREATE TABLE IF NOT EXISTS kasbon_requests (
  id            VARCHAR(40) PRIMARY KEY,
  project_id    VARCHAR(40) NOT NULL,
  worker_id     VARCHAR(40) NULL,                 -- NULL = atas nama tim / grup / penanggung jawab
  tim           VARCHAR(80) NOT NULL DEFAULT '',   -- nama tim bila atas nama tim
  batch_id      VARCHAR(40) NULL,                  -- satu pengajuan berisi beberapa tim/pekerja
  jumlah        DECIMAL(14,2) NOT NULL,
  ket           VARCHAR(255) NOT NULL DEFAULT '',
  status        ENUM('diajukan','disetujui','ditolak') NOT NULL DEFAULT 'diajukan',
  catatan       VARCHAR(255) NOT NULL DEFAULT '',  -- alasan penolakan / catatan akuntan
  kasbon_id     VARCHAR(40) NULL,                  -- baris buku kasbon yang dibuat saat disetujui
  created_by    VARCHAR(40) NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  diproses_by   VARCHAR(40) NULL,
  diproses_at   DATETIME NULL,
  INDEX idx_kreq_status (status, created_at),
  INDEX idx_kreq_project (project_id),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (worker_id) REFERENCES workers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

