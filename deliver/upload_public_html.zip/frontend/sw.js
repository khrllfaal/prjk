/* Offline shell for the app. Bump VERSION on every deploy so phones pick up
   new frontend files. API responses are deliberately not cached here: stock
   and transaction data stay out of the browser cache, and offline writes go
   through the app's own outbox instead. */
const VERSION = 'v6-2026-10-20';
const SHELL = 'ms-shell-' + VERSION;
const SHELL_FILES = [
  './', './index.html', './backend-config.js',
  './vendor/tailwind.css', './vendor/icons.js',
  './manifest.webmanifest', './logo.png', './icon-192.png'
];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(SHELL).then(function (c) { return c.addAll(SHELL_FILES); }).then(function () { return self.skipWaiting(); }));
});

self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (keys) {
    return Promise.all(keys.filter(function (k) { return k !== SHELL; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});

self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET') return;
  var url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  // API calls are never cached, whatever folder the backend lives in (e.g. /backend/api, /coba/api).
  if (url.pathname.indexOf('/backend/') !== -1 || url.pathname.indexOf('/api/') !== -1 || /\.php$/.test(url.pathname)) return;

  if (req.mode === 'navigate') {
    e.respondWith(fetch(req).then(function (res) {
      var copy = res.clone();
      caches.open(SHELL).then(function (c) { c.put('./index.html', copy); });
      return res;
    }).catch(function () { return caches.match('./index.html'); }));
    return;
  }

  e.respondWith(caches.match(req).then(function (hit) {
    var net = fetch(req).then(function (res) {
      if (res.ok) { var copy = res.clone(); caches.open(SHELL).then(function (c) { c.put(req, copy); }); }
      return res;
    }).catch(function () { return hit; });
    return hit || net;
  }));
});
